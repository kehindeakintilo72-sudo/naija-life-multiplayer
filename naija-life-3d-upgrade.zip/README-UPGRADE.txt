Naija Life Multiplayer — 3D city upgrade

This adds a first playable 3D district to the existing project:
- 3D buildings, streets, trees, market stalls
- WASD/arrow controls on desktop and touch direction pad on mobile
- Socket.IO position broadcasts so online players can see one another
- Keeps existing login, jobs, properties, and chat

Files:
- city3d.js: upload to the repository at public/city3d.js
- server-socket-snippet.txt: make the small server.js changes shown
- index-snippets.txt: add the CSS/HTML/script references shown

Important:
1. Add app.set("trust proxy", 1); directly after const app = express(); if it is not already there.
2. Apply the server snippets carefully. Do not replace the whole server.js.
3. Upload city3d.js to public/city3d.js.
4. Apply the index.html snippets exactly once. Add the startCity call after connectChat() so the Socket.IO connection exists first.
5. Commit all changes to main. Render should auto-deploy.
6. Open https://naija-life-multiplayer.onrender.com, refresh, log in, and test movement.

This is a prototype foundation. Player positions are held in server memory, so they reset on redeploy/restart. For production, add persistent storage and validate more game actions server-side. Three.js is loaded from jsDelivr, so the browser needs internet access.
